# BIKE WRAP SONU — Android prototype

## Open in Android Studio
1. Extract this ZIP.
2. Open the `BIKE_WRAP_SONU` folder in Android Studio.
3. Allow Gradle sync and install the Android SDK components if prompted.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

## Current prototype
- Android WebView app shell
- Interactive Three.js concept motorcycle
- Drag to rotate and zoom
- Body and wheel colour selection
- Wrap finish, rim style, exhaust, mirrors, windshield, crash guard and seat controls

## Important
This is a starter prototype, not a finished production app. The current bike is a generic procedural 3D concept model. Exact licensed/manufacturer 3D models, model-specific fitment, expanded accessory catalogues, offline 3D libraries, screenshots/export and final APK signing are future development steps. Three.js libraries currently load from a CDN, so first launch needs internet access.
